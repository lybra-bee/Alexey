#!/bin/bash
export HF_API_KEY="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"
export ADMIN_TOKEN="WVVj3EZhk1QfAyrlXO0vEkzHNp3AtIQZ"
export CACHE_TTL_HOURS=3
python3 server.py
