# News Service

ADMIN_TOKEN: WVVj3EZhk1QfAyrlXO0vEkzHNp3AtIQZ

## Запуск локально
```bash
bash start_local.sh
```
